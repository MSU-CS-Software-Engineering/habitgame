# name, image, value, uses, [effect]
software_list = [
["Smokescreen", "PLACEHOLDER.JPG", 50,  1],
["Fork",        "PLACEHOLDER.JPG", 150, 2],
["Fortify",     "PLACEHOLDER.JPG", 75,  2],
["Disrupt",     "PLACEHOLDER.JPG", 100, 1],
["Sleep",       "PLACEHOLDER.JPG", 200, 4],
["Glamour",     "PLACEHOLDER.JPG", 100, 1],

]


hardware_list = [
["RAM Upgrade",         "PLACEHOLDER.JPG", 100, -1],
["CPU Upgrade",         "PLACEHOLDER.JPG", 150, -1],
["Hardware Relocation", "PLACEHOLDER.JPG", 200,  1],
["Botnet Expansion",    "PLACEHOLDER.JPG", 300, -1],
["Add Proxy Server",    "PLACEHOLDER.JPG", 200, -1],
["Trunkline Tap",       "PLACEHOLDER.JPG", 100, -1],

]

rank_list = [
"N00b",
"Script Kiddie",
"Programming Neophyte",
"Code Poet",
"Initiate Hacker",
"Journeyman Hacker",
"Open Sourceeror",
"Hacker Elite",
"Grandmaster of the Internet",
]

boss_list = [
"FBI Cybercrimes Unit",
"PLA Unit 61398",
"Cult of the Dead Cow",
"Kevin Mitnick",
"Hacker1",
]
